
function Login() {
  return (
    <main>
      <h1>Iniciar sesión</h1>
      <p>Bienvenido de nuevo a DOBBY PLACE.</p>
    </main>
  );
}

export default Login;
