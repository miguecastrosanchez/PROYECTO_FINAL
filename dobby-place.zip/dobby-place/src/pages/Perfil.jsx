
function Perfil() {
  return (
    <main>
      <h1>Mi perfil</h1>
      <p>Mis publicaciones y favoritos.</p>
    </main>
  );
}

export default Perfil;
