
import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav className="navbar-dobby">

      {/* LOGO DOBBY PLACE */}
      <Link to="/" className="logo">
        <img
          src="/assets/logo-dobby.png"
          alt="Logo de DOBBY PLACE"
          className="logo-icono"
        />

        <span className="logo-texto">
          DOBBY<span>PLACE.</span>
        </span>
      </Link>

      {/* MENÚ CENTRAL */}
      <div className="navbar-links">
        <Link to="/explorar">
          Explorar
        </Link>

        <Link to="/explorar">
          Categorías
        </Link>
      </div>

      {/* ACCESOS DE USUARIOS */}
      <div className="navbar-usuarios">

        {/* INICIAR SESIÓN */}
        <Link
          to="/login"
          title="Iniciar sesión"
          aria-label="Iniciar sesión"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <circle cx="12" cy="8" r="4" />
            <path d="M4 21v-2a8 8 0 0 1 16 0v2" />
          </svg>
        </Link>

        {/* CREAR CUENTA */}
        <Link
          to="/registro"
          title="Crear cuenta"
          aria-label="Crear cuenta"
        >
          <svg
            viewBox="0 0 32 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <circle cx="10" cy="7" r="4" />
            <path d="M2 21v-2a8 8 0 0 1 16 0v2" />
            <path
              d="M25 5v12 M19 11h12"
              strokeWidth="2.5"
            />
          </svg>
        </Link>

      </div>
    </nav>
  );
}

export default Navbar;
